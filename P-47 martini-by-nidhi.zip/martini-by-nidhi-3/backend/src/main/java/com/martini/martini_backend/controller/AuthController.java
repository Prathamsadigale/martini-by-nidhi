package com.martini.martini_backend.controller;

import com.martini.martini_backend.model.User;
import com.martini.martini_backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import com.martini.martini_backend.security.JwtUtil;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // SIGNUP
    @PostMapping("/signup")
    public Map<String, String> signup(@RequestBody User user) {

        Map<String, String> response = new HashMap<>();

        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            response.put("message", "Email already exists");
            return response;
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole("USER");
        userRepository.save(user);

        response.put("message", "Signup successful");
        return response;
    }

    // LOGIN
    @PostMapping("/login")
    public Map<String, String> login(@RequestBody User loginData) {

        Map<String, String> response = new HashMap<>();

        User user = userRepository.findByEmail(loginData.getEmail()).orElse(null);

        if (user == null) {
            response.put("message", "User not found");
            return response;
        }

        if (!passwordEncoder.matches(loginData.getPassword(), user.getPassword())) {
            response.put("message", "Invalid password");
            return response;
        }

        String token = JwtUtil.generateToken(user.getEmail(), user.getRole());

        response.put("message", "Login successful");
        response.put("token", token);
        response.put("role", user.getRole());

        return response;
    }
}
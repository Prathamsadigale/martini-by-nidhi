package com.martini.martini_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MartiniBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
